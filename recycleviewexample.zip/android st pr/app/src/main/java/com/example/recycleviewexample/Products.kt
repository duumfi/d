package com.example.recycleviewexample

import android.icu.text.CaseMap.Title
import android.media.Image

data class Items(val image: Int, val title: String)
