package com.example.recycleviewexample

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.recycleviewexample.databinding.ItemsItemBinding

class ItemsAdaptor: RecyclerView.Adapter<ItemsAdaptor.ItemsHolder>() {
    val itemList = ArrayList<Items>()
    class ItemsHolder(item: View): RecyclerView.ViewHolder(item)    {
        val binding = ItemsItemBinding.bind(item)
         fun bind(item: Items) = with(binding){
             im.setImageResource(item.image)
             tTittle.text = item.title
         }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemsHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.items_item, parent, false)
        return ItemsHolder(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: ItemsHolder, position: Int) {
        holder.bind(itemList[position])
    }
    fun addItems(item: Items){
        itemList.add(item)
        notifyDataSetChanged()
    }
}   